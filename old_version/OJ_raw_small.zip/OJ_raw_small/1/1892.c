#include <string.h>
#include <math.h>
#include <stdio.h>
int ans = 0;
int  work(int p,int k)
{	if (p==1) {ans++; return (p*k,k);}
	for(int i =k;i <= p;i ++){
		if(p % i == 0){
			work(p / i,i);
		
             
		}
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	while(n--){
		ans = 0;
		int t;
		scanf("%d",&t);
		work(t,2);
		 
		printf("%d\n",ans);
	}
	
	return 0;
}