#include <string.h>
#include <math.h>
#include <stdio.h>
 
 
 
 
 
 
 

int f(int a,int s) 
{
    if(a<=s) return 1;
	int b=sqrt((float)a),flag=0,sum=1;
	for(int i=s;i<=b;i++)
	{
		if(a%i==0)
		{
			flag++;
            
			sum=sum+f(a/i,i);
		}
	}
	if(flag==0) return 1;
	else return sum;
}



int main()
{
	int a,n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a;
		cout<<f(a,2)<<endl;
	}
	
    return 0;
}
